package com.example.c196_zelalem_t;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.example.c196_zelalem_t.Database.dbHelper;
import com.example.c196_zelalem_t.Models.Assessment;
import com.example.c196_zelalem_t.Models.Course;
import com.example.c196_zelalem_t.Models.Term;

import java.util.ArrayList;
import java.util.List;

import static com.example.c196_zelalem_t.TermsActivity.getTermId;

public class AssessmentsActivity extends AppCompatActivity {
    Button btnAddAssessments;

    ListView assessmentListView;
    ArrayList<Assessment> assessmentArrayList;
     AssessmentAdapter assessmentAdapter;
    dbHelper myHelper;

    public static Assessment selectedAssessment;

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assessments);
        getSupportActionBar().setTitle("List of Assessments");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        //add assessment
        btnAddAssessments = findViewById(R.id.btnAddAssessment);
        btnAddAssessments.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent assesst = new Intent(AssessmentsActivity.this, AddAssessment.class);
                startActivity(assesst);
            }
        });

        myHelper = new dbHelper(this);
        loadAssessmentDataToListView();


        //on item click
        assessmentListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent assess = new Intent(getApplicationContext(), EditAssessment.class);
                selectedAssessment = assessmentArrayList.get(i);
                int assessId = selectedAssessment.getAssessmentId();
                assess.putExtra("assessmentId",assessId);
                startActivity(assess);
            }
        });




    }


    public  void loadAssessmentDataToListView() {
        try {
            assessmentListView = findViewById(R.id.lvListOfAssessments);

            assessmentArrayList = myHelper.getAssessmentsList();
            assessmentAdapter = new AssessmentAdapter(this, assessmentArrayList);
            assessmentListView.setAdapter(assessmentAdapter);
            assessmentAdapter.notifyDataSetChanged();
        } catch (Exception e) {
            e.toString();
        }
    }






    //Home from action bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuItem item = menu.add("Home");
        item.setIcon(R.drawable.ic_baseline_home_24);
        item.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        item.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {

            @Override
            public boolean onMenuItemClick(MenuItem item) {
                // TODO Auto-generated method stub
                Intent in = new Intent(AssessmentsActivity.this, MainActivity.class);
                startActivity(in);
                return true;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }

    //back button
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent myIntent = new Intent(AssessmentsActivity.this, MainActivity.class);
        startActivityForResult(myIntent, 0);
        return true;
    }
}