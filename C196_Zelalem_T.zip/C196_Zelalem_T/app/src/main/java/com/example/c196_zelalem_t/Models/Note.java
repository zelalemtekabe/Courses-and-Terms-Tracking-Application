package com.example.c196_zelalem_t.Models;

public class Note {
    public int noteId;
    public String noteTitle;
    public int courseId;

    public Note(int noteId, String noteTitle, int courseId) {
        this.noteId = noteId;
        this.noteTitle = noteTitle;
        this.courseId = courseId;
    }

    public int getNoteId() {
        return noteId;
    }

    public String getNoteTitle() {
        return noteTitle;
    }

    public int getCourseId() {
        return courseId;
    }

    public void setNoteId(int noteId) {
        this.noteId = noteId;
    }

    public void setNoteTitle(String noteTitle) {
        this.noteTitle = noteTitle;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }
}
