package com.example.c196_zelalem_t.Models;

public  class Term {
    private int termId;
    private String termName;
    private String termStart;
    private String termEnd;

    public Term() {

    }

    public Term(int termId, String termName, String termStart, String termEnd) {
        this.termId = termId;
        this.termName = termName;
      this.termStart = termStart;
       this.termEnd = termEnd;
    }



    public int getTermId() { return termId;  }

    public String getTermName() {
        return termName;
    }

    public String getTermStart() {
        return termStart;
    }

    public String getTermEnd() {
        return termEnd;
    }

    public void setTermId(int termId) {
        this.termId = termId;
    }

    public void setTermName(String termName) {
        this.termName = termName;
    }

    public void setTermStart(String termStart) {
        this.termStart = termStart;
    }

    public void setTermEnd(String termEnd) {
        this.termEnd = termEnd;
    }
}


