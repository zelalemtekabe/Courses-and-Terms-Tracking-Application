package com.example.c196_zelalem_t.ui.courses;

import android.content.Intent;
import android.view.View;
import android.widget.Button;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.c196_zelalem_t.AddTerm;
import com.example.c196_zelalem_t.R;
import com.example.c196_zelalem_t.TermsActivity;

public class CoursesViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public CoursesViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is slideshow fragment" );

    }







    public LiveData<String> getText() {
        return mText;
    }
}