package com.example.c196_zelalem_t.ui.assessments;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class AssessmentsViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public AssessmentsViewModel() {

        mText = new MutableLiveData<>();
        mText.setValue("This assessment" );

    }

    public LiveData<String> getText() {
        return mText;
    }
}