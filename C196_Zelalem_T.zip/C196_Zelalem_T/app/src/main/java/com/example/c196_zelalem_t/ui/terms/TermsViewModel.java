package com.example.c196_zelalem_t.ui.terms;

import android.content.Intent;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class TermsViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public TermsViewModel() {

        mText = new MutableLiveData<>();
        mText.setValue("This is gallery fragment" );


    }

    public LiveData<String> getText() {
        return mText;
    }
}