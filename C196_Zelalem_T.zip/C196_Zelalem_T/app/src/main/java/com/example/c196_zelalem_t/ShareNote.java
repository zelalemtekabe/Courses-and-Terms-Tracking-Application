package com.example.c196_zelalem_t;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.example.c196_zelalem_t.Database.dbHelper;

public class ShareNote extends AppCompatActivity {
    PopupWindow popup;
    boolean click = true;
    dbHelper herlper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share_note);
        getSupportActionBar().setTitle("Send Note as SMS");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

//        String phoneNr ="7169399916";//"7043452910";//"7043452835";// "+19803193223";
//        SmsManager sms =  SmsManager.getDefault();
//        sms.sendTextMessage(phoneNr, null," ...hi tag you're it.", null, null);
//        Toast.makeText(getApplicationContext(),"Is sent ....",Toast.LENGTH_SHORT).show();

        //



    }



    //Home from action bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuItem item = menu.add("Home");
        item.setIcon(R.drawable.ic_baseline_home_24);
        item.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        item.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {

            @Override
            public boolean onMenuItemClick(MenuItem item) {
                // TODO Auto-generated method stub
                Intent in = new Intent(ShareNote.this, MainActivity.class);
                startActivity(in);
                return true;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent myIntent = new Intent(getApplicationContext(), CourseDetail.class);
        startActivityForResult(myIntent, 0);
        return true;
    }
}