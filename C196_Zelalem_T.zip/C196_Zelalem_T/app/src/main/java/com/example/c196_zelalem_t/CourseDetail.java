package com.example.c196_zelalem_t;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.service.autofill.OnClickAction;
import android.telephony.SmsManager;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.c196_zelalem_t.Database.dbHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class CourseDetail extends AppCompatActivity {

    final Calendar sCalendar = Calendar.getInstance();
    final Calendar eCalendar = Calendar.getInstance();
    DatePickerDialog.OnDateSetListener sDate;
    DatePickerDialog.OnDateSetListener eDate;

    private EditText startDate, endDate;

    TextView termName, termStart, termEnd, courseName, courseStart, courseEnd, mentor, mentorPhone, mentorEmail, notes;
    String termNameS, termStartS, termEndS, courseNameS, courseStartS, courseEndS, statusS, mentorS, mentorPhoneS, mentorEmailS, notz;
    dbHelper helper;
    long termId;
    private Spinner status;
    Button btnEditCourse, btnSaveCourseEdit, btnCancelCourseEdit, btnDeleteCourse, btnShareNote;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_detail);

        getSupportActionBar().setTitle("Course Detail");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        //Date selection
        startDate = findViewById(R.id.txtCourseStart_CorsDet);
        sDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                sCalendar.set(Calendar.YEAR, year);
                sCalendar.set(Calendar.MONTH, monthOfYear);
                sCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateStartLabel();
                sCalendar.clear();//?
            }

        };

        endDate = findViewById(R.id.txtCourseEnd_CorsDet);
        eDate = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                eCalendar.set(Calendar.YEAR, year);
                eCalendar.set(Calendar.MONTH, monthOfYear);
                eCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateEndLabel();
                eCalendar.clear();//?
            }

        };

        startDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                new DatePickerDialog(CourseDetail.this, sDate, sCalendar
                        .get(Calendar.YEAR), sCalendar.get(Calendar.MONTH),
                        sCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }

        });

        endDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                new DatePickerDialog(CourseDetail.this, eDate, eCalendar
                        .get(Calendar.YEAR), eCalendar.get(Calendar.MONTH),
                        eCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }

        });

        // Share note
        btnShareNote = findViewById(R.id.btnShareNote);
        btnShareNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("text/plain");
                String body = getCourseNote();
                String subject = "Notes for course: " + getTitle();
                shareIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
                shareIntent.putExtra(Intent.EXTRA_TEXT, body);
                startActivity(Intent.createChooser(shareIntent, "Share using"));

//                String phoneNr = "12345";
//                SmsManager sms = SmsManager.getDefault();
//
//                String courseNote = getCourseNote();
//                sms.sendTextMessage(phoneNr, null, courseNote, null, null);
//                Toast.makeText(getApplicationContext(), "The note is sent.", Toast.LENGTH_SHORT).show();
            }
        });


        //populate spinner
        status = findViewById(R.id.txtStatusEdit);
        dbHelper hStatus = new dbHelper(this);

        int cId = TermDetail.selectedCourse.getCourseId();
        String currentStatus = hStatus.getStatus(cId);

        List<String> list = new ArrayList<String>();
        list.add("In Progress");
        list.add("Completed");
        list.add("Dropped");
        list.add("Plan to take");
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        status.setAdapter(adapter);

        if (currentStatus != null) {
            int spinnerPosition = adapter.getPosition(currentStatus);
            status.setSelection(spinnerPosition);
        }


        getCourseDetails();

        //Save button
        btnSaveCourseEdit = findViewById(R.id.btnSave_CorsDet);
        //disable save button onload
        btnSaveCourseEdit.setVisibility(View.GONE);
        final TextView txtSaveText;
        txtSaveText = findViewById(R.id.txtSaveText);
        txtSaveText.setVisibility(View.GONE);

        btnSaveCourseEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updateCourse();
                btnSaveCourseEdit.setVisibility(View.GONE);
                txtSaveText.setVisibility(View.GONE);

            }
        });

        //Edit button
        btnEditCourse = findViewById(R.id.btnEdit_CorsDet);
        btnEditCourse.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceType")
            @Override
            public void onClick(View view) {
                btnSaveCourseEdit.setVisibility(View.VISIBLE);
                txtSaveText.setVisibility(View.VISIBLE);

                courseName.setFocusableInTouchMode(true);
                courseStart.setFocusableInTouchMode(true);
                courseEnd.setFocusableInTouchMode(true);
                status.setFocusableInTouchMode(true);
                mentor.setFocusableInTouchMode(true);
                mentorPhone.setFocusableInTouchMode(true);
                mentorEmail.setFocusableInTouchMode(true);
                notes.setFocusableInTouchMode(true);

                courseName.setBackgroundColor(Color.parseColor("#FFFF00"));
                status.setBackgroundColor(Color.parseColor("#FFFF00"));
                mentor.setBackgroundColor(Color.parseColor("#FFFF00"));
                mentorPhone.setBackgroundColor(Color.parseColor("#FFFF00"));
                mentorEmail.setBackgroundColor(Color.parseColor("#FFFF00"));
                notes.setBackgroundColor(Color.parseColor("#FFFF00"));


                courseName.requestFocus();

            }
        });


        //Cancel button
        btnCancelCourseEdit = findViewById(R.id.btnCancel_CorsDet);
        btnCancelCourseEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent cancelInt = new Intent(CourseDetail.this, TermDetail.class);
                startActivity(cancelInt);
                //    finish();
            }
        });


        //Delete button
        btnDeleteCourse = findViewById(R.id.btnDeleteCourse);
        btnDeleteCourse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                deleteCourse();
            }
        });

//
//        //Share note
//        btnShareNote =findViewById(R.id.btnShareNote);
//        btnShareNote.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent shareSms = new Intent(CourseDetail.this, ShareNote.class);
//
//
//                startActivity(shareSms);
//
//            }
//        });
    }

    //Home from action bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuItem item = menu.add("Home");
        item.setIcon(R.drawable.ic_baseline_home_24);
        item.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        item.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {

            @Override
            public boolean onMenuItemClick(MenuItem item) {
                Intent in = new Intent(CourseDetail.this, MainActivity.class);
                startActivity(in);
                return true;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) throws SQLException {

        Intent myIntent = new Intent(getApplicationContext(), TermsActivity.class);
        TermDetail t = new TermDetail();

        startActivityForResult(myIntent, 0);
        return true;
    }

    public void getCourseDetails() {
        int cId = TermDetail.selectedCourse.getCourseId();

        helper = new dbHelper(CourseDetail.this);
        SQLiteDatabase db;
        db = helper.getReadableDatabase();

        String q = " select  t.termName, t.termStart, t.termEnd,c.courseName, c.startDate" +
                ", c.endDate, c.status, c.mentorName, c.mentorPhone, c.mentorEmail, c.notes " +
                " from TermTable t join CoursesTable c on t.termId = c.termId " +
                " Where courseId = " + cId;
        Cursor qry = db.rawQuery(q, null);

        // db.close();

        termName = findViewById(R.id.txtTermName_CorsDet);
        termStart = findViewById(R.id.txtTermStartDate_CorsDet);
        termEnd = findViewById(R.id.txtTermEndDate_CorsDet);

        courseName = findViewById(R.id.txtCourseName_CorsDet);
        courseStart = findViewById(R.id.txtCourseStart_CorsDet);
        courseEnd = findViewById(R.id.txtCourseEnd_CorsDet);
        status = findViewById(R.id.txtStatusEdit);
        mentor = findViewById(R.id.txtMentor_CorsDe);
        mentorPhone = findViewById(R.id.txtMentorPhone_CorsDe);
        mentorEmail = findViewById(R.id.txtMentorEmail_CorsDe);
        notes = findViewById(R.id.txtNotes);

        courseName.setFocusable(false);
        courseStart.setFocusable(false);
        courseEnd.setFocusable(false);
        status.setFocusable(false);
        mentor.setFocusable(false);
        mentorPhone.setFocusable(false);
        mentorEmail.setFocusable(false);
        notes.setFocusable(false);


        while (qry.moveToNext()) {

            termNameS = qry.getString(0);
            termStartS = qry.getString(1);
            termEndS = qry.getString(2);
            courseNameS = qry.getString(3);
            courseStartS = qry.getString(4);
            courseEndS = qry.getString(5);
            statusS = qry.getString(6);
            mentorS = qry.getString(7);
            mentorPhoneS = qry.getString(8);
            mentorEmailS = qry.getString(9);
            notz = qry.getString(10);

            termName.setText(termNameS);
            termStart.setText(termStartS);
            termEnd.setText(termEndS);
            courseName.setText(courseNameS);
            courseStart.setText(courseStartS);
            courseEnd.setText(courseEndS);

            mentor.setText(mentorS);
            mentorPhone.setText(mentorPhoneS);
            mentorEmail.setText(mentorEmailS);
            notes.setText(notz);
        }
    }


    private void updateCourse() {
        int cId = TermDetail.selectedCourse.getCourseId();

        courseNameS = "" + courseName.getText().toString().trim();
        courseStartS = "" + courseStart.getText().toString().trim();
        courseEndS = "" + courseEnd.getText().toString().trim();
        statusS = "" + status.getSelectedItem().toString().trim();
        mentorS = "" + mentor.getText().toString().trim();
        mentorPhoneS = "" + mentorPhone.getText().toString().trim();
        mentorEmailS = "" + mentorEmail.getText().toString().trim();
        notz = "" + notes.getText().toString().trim();


        if (courseNameS.isEmpty() || courseStartS.isEmpty() || courseEndS.isEmpty() || statusS.isEmpty()
                || mentorS.isEmpty() || mentorPhoneS.isEmpty() || mentorEmailS.isEmpty()) {
            Toast.makeText(CourseDetail.this, "One or more fields are empty, please correct.", Toast.LENGTH_SHORT).show();
        } else {

            try {

                helper = new dbHelper(CourseDetail.this);

                SQLiteDatabase db;
                db = helper.getWritableDatabase();
                db.execSQL("UPDATE CoursesTable SET courseName = " + "'" + courseNameS + "'"
                        + ", startDate = " + "'" + courseStartS + "'"
                        + ", endDate = " + "'" + courseEndS + "'"
                        + ", status = " + "'" + statusS + "'"
                        + ", mentorName = " + "'" + mentorS + "'"
                        + ", mentorPhone = " + "'" + mentorPhoneS + "'"
                        + ", mentorEmail = " + "'" + mentorEmailS + "'"
                        + ", notes = " + "'" + notz + "'"
                        + " WHERE courseId = " + cId);

                courseName.setFocusable(false);
                courseStart.setFocusable(false);
                courseEnd.setFocusable(false);
                status.setFocusable(false);
                mentor.setFocusable(false);
                mentorPhone.setFocusable(false);
                mentorEmail.setFocusable(false);
                notes.setFocusable(false);

                courseName.setBackgroundColor(Color.parseColor("#FFFFFF"));
                status.setBackgroundColor(Color.parseColor("#FFFFFF"));
                mentor.setBackgroundColor(Color.parseColor("#FFFFFF"));
                mentorPhone.setBackgroundColor(Color.parseColor("#FFFFFF"));
                mentorEmail.setBackgroundColor(Color.parseColor("#FFFFFF"));
                notes.setBackgroundColor(Color.parseColor("#FFFFFF"));
                Toast.makeText(CourseDetail.this, "The changes are now saved.", Toast.LENGTH_SHORT).show();

                TermDetail t = new TermDetail();
                t.loadCourseDataToListView();

                // finish();

            } catch (SQLException ex) {
                ex.toString();
            }

        }
    }


    public void deleteCourse() {
        int cId = TermDetail.selectedCourse.getCourseId();
        try {

            helper = new dbHelper(CourseDetail.this);
            SQLiteDatabase db;
            db = helper.getWritableDatabase();
            db.execSQL("DELETE FROM CoursesTable WHERE courseId = " + cId);
            db.close();
            Toast.makeText(this, "The Course is now deleted.", Toast.LENGTH_SHORT).show();
            Intent delIntent = new Intent(CourseDetail.this, TermDetail.class);
            startActivity(delIntent);

        } catch (SQLException e) {
            e.getStackTrace();
        }

    }


    public String getCourseNote() {
        int cId = TermDetail.selectedCourse.getCourseId();
        String cNote = "";
        SQLiteDatabase db;
        helper = new dbHelper(CourseDetail.this);
        db = helper.getReadableDatabase();
        try {
            Cursor cursor = db.rawQuery("SELECT courseId, notes FROM CoursesTable WHERE courseId = " + cId, null);
            while (cursor.moveToNext()) {
                cNote = cursor.getString(1);
            }
        } catch (SQLException e) {
            e.toString();
        }

        return "Course Notes for Course - " + courseNameS + " : " + cNote;
    }

    private void updateStartLabel() {
        String mysFormat = "MM/dd/yy";
        SimpleDateFormat sdfS = new SimpleDateFormat(mysFormat, Locale.US);

        startDate.setText(sdfS.format(sCalendar.getTime()));
    }

    private void updateEndLabel() {
        String myEFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myEFormat, Locale.US);
        endDate.setText(sdf.format(eCalendar.getTime()));
    }


}