package com.example.c196_zelalem_t.Database;

import android.database.Cursor;

public class TermTable {
    public static final String TABLE_TERMTABLE = "TermTable";
    public static final String COLUMN_ID = "termId";
    public static final String COLUMN_NAME = "termName";
    public static final String COLUMN_TERMSTART = "termStart";
    public static final String COLUMN_TERMEND = "termEnd";
    public static final String[] TABLE_COLUMNS = {COLUMN_ID,COLUMN_NAME,COLUMN_TERMSTART,COLUMN_TERMEND};
    private Cursor cursor;


    public static final  String createTermTable =
           "CREATE TABLE " + TABLE_TERMTABLE +  " ( "+ COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + COLUMN_NAME + " TEXT,"
            + COLUMN_TERMSTART + " TEXT,"
           + COLUMN_TERMEND + " TEXT"
                 +");";

    public static final String deleteTermTable =
            "DROP TABLE " + TABLE_TERMTABLE;




}



