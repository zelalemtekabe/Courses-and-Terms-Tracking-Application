package com.example.c196_zelalem_t;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.c196_zelalem_t.Database.dbHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class AddAssessment extends AppCompatActivity {


    final Calendar Cal  = Calendar.getInstance();
    DatePickerDialog.OnDateSetListener sDate,eDate;

    private Spinner assementType,courseName;
    private EditText crsName, startDate, endDate,assessName;
    String cName, startS,endS, daasmntType,assessNameS;


    private dbHelper myHelper, helper;
    Button btnSaveAssessment;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_assessment);

        getSupportActionBar().setTitle("Add a new Assessment");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);



        //load assessment type spinner
        assementType = findViewById(R.id.txtAssessmentType);
        List<String> typeList = new ArrayList<String>();
        typeList.add("Performance Assessment");
        typeList.add("Objective Assessment");

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, typeList);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        assementType.setAdapter(arrayAdapter);




        //load course spinner
        courseName = findViewById(R.id.txtCourse4Assessment);
        myHelper = new dbHelper(this);
        List<String > cList =  myHelper.getCoursesList();
        ArrayAdapter<String> courseAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, cList);
        courseAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        courseName.setAdapter(courseAdapter);

        //date dropdown
        startDate = findViewById(R.id.txtAssessStart);
        sDate = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                Cal.set(Calendar.YEAR, year);
                Cal.set(Calendar.MONTH, monthOfYear);
                Cal.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                updateStartDateLabel();
            }
        };

        startDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                new DatePickerDialog(AddAssessment.this, sDate, Cal
                        .get(Calendar.YEAR), Cal.get(Calendar.MONTH),
                        Cal.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        endDate = findViewById(R.id.txtAssessEnd);
        eDate = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                Cal.set(Calendar.YEAR, year);
                Cal.set(Calendar.MONTH, monthOfYear);
                Cal.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                updateEndDateLabel();
            }
        };

        endDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                new DatePickerDialog(AddAssessment.this, eDate, Cal
                        .get(Calendar.YEAR), Cal.get(Calendar.MONTH),
                        Cal.get(Calendar.DAY_OF_MONTH)).show();
            }
        });



        //btnSaveAssessment
        btnSaveAssessment = findViewById(R.id.btnSaveAssessment);
        helper = new dbHelper(this);
        btnSaveAssessment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               insertAssessment();
            }
        });

    }


    public void insertAssessment(){
     courseName = findViewById(R.id.txtCourse4Assessment);
     assementType = findViewById(R.id.txtAssessmentType);
     assessName = findViewById(R.id.txtAssessmentName);
     startDate = findViewById(R.id.txtAssessStart);
     endDate = findViewById(R.id.txtAssessEnd);

     cName = "" + courseName.getSelectedItem().toString().trim();
     daasmntType = "" + assementType.getSelectedItem().toString().trim();
     assessNameS = "" + assessName.getText().toString().trim();
     startS = "" + startDate.getText().toString().trim();
     endS = "" + endDate.getText().toString().trim();

     int  cId = helper.courseId(cName.trim());

    if(myHelper.getAssessmentCountPerCourse(cName)){
        Toast.makeText(getApplicationContext(),"A maximum of 5 assessments is allowed per course.",Toast.LENGTH_SHORT).show();
    }
    else {
        if (cName.isEmpty() || startS.isEmpty() || endS.isEmpty() || daasmntType.isEmpty() || assessNameS.isEmpty()  ) {
            Toast.makeText(AddAssessment.this, "One or more fields are empty, please correct.", Toast.LENGTH_SHORT).show();

        } else {

            try {

                long id = myHelper.insertAssessment(daasmntType,assessNameS, cId, cName, startS,endS); //
                Toast.makeText(this, "The assessment is now added.", Toast.LENGTH_SHORT).show();
                Intent termInt = new Intent(getApplicationContext(), AssessmentsActivity.class);
                startActivity(termInt);
                //  finish();

            } catch (Exception e) {
                e.getMessage();
            }
        }

    }



    }



    private void updateStartDateLabel() {
        String mysFormat = "MM/dd/yy";
        SimpleDateFormat sdfS = new SimpleDateFormat(mysFormat, Locale.US);
        startDate.setText(sdfS.format(Cal.getTime()));
    }
    private void updateEndDateLabel() {
        String mysFormat = "MM/dd/yy";
        SimpleDateFormat sdfS = new SimpleDateFormat(mysFormat, Locale.US);

        endDate.setText(sdfS.format(Cal.getTime()));
    }

    //Home from action bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuItem item=menu.add("Home");
        item.setIcon(R.drawable.ic_baseline_home_24);
        item.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        item.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {

            @Override
            public boolean onMenuItemClick(MenuItem item) {
                Intent in = new Intent(AddAssessment.this,MainActivity.class);
                startActivity(in);
                return true;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected( MenuItem item) {
        Intent myIntent = new Intent(getApplicationContext(), AssessmentsActivity.class);
        startActivityForResult(myIntent, 0);
        return true;
    }
}