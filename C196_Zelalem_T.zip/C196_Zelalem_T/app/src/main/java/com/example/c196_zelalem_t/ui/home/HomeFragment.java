package com.example.c196_zelalem_t.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.c196_zelalem_t.CourseDetail;
import com.example.c196_zelalem_t.Database.dbHelper;
import com.example.c196_zelalem_t.R;

public class HomeFragment extends Fragment {

    private HomeViewModel homeViewModel;
    TextView txtTerms, txtCourses,txtAssessments;
    String termsCount, coursesCount,assessmentCount;

    @Override
    public void onStart() {
        super.onStart();
    }


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        homeViewModel =
                ViewModelProviders.of(this).get(HomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        final TextView textView = root.findViewById(R.id.text_home);

        //Summary info
            dbHelper myH;
            myH = new dbHelper(getActivity());

            int terms = myH.getSummary(0);
            int courses = myH.getSummary(1);
            int assessments = myH.getSummary(2);

            txtTerms = root.findViewById(R.id.txtNrOfTerms);
            txtCourses = root.findViewById(R.id.txtNrOfCourses);
            txtAssessments = root.findViewById(R.id.txtNrOfAssessments);

        txtTerms.setText(String.valueOf(terms));
        txtCourses.setText(String.valueOf(courses));
        txtAssessments.setText(String.valueOf(assessments));

        homeViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }

        });
        return root;





    }
}