package com.example.c196_zelalem_t;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.c196_zelalem_t.Database.dbHelper;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;

import static com.example.c196_zelalem_t.TermsActivity.getTermId;
import static com.example.c196_zelalem_t.TermsActivity.selectedTerm;

public class AddCourse extends AppCompatActivity {


    final Calendar sCalendar = Calendar.getInstance();
    final Calendar eCalendar = Calendar.getInstance();
    DatePickerDialog.OnDateSetListener sDate;
    DatePickerDialog.OnDateSetListener eDate;

    private EditText courseName, cStartDate, cEndDate, mentorName, mentorPhone, mentorEmail, notes;
    private Spinner status;
    private Button btnSvTerm;
    private dbHelper myHelper;
    String courseId, cName, startD, endD, cStatus, mentName, mentPhone, mentEmail, notz;
    int tId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_course);
        getSupportActionBar().setTitle("Add a new Course");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        //load spinner for status
        status = findViewById(R.id.txtStatus);
        List<String> list = new ArrayList<String>();
        list.add("In Progress");
        list.add("Completed");
        list.add("Dropped");
        list.add("Plan to take");

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        status.setAdapter(adapter);

        //start and end date drop downs
        cStartDate = findViewById(R.id.txtCourseStartDate);
        sDate = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                sCalendar.set(Calendar.YEAR, year);
                sCalendar.set(Calendar.MONTH, monthOfYear);
                sCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateStartLabel();
            }

        };

        cEndDate = findViewById(R.id.txtCourseEndDate);
        eDate = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                eCalendar.set(Calendar.YEAR, year);
                eCalendar.set(Calendar.MONTH, monthOfYear);
                eCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateEndLabel();
            }

        };

        cStartDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                new DatePickerDialog(AddCourse.this, sDate, sCalendar
                        .get(Calendar.YEAR), sCalendar.get(Calendar.MONTH),
                        sCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }

        });

        cEndDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                new DatePickerDialog(AddCourse.this, eDate, eCalendar
                        .get(Calendar.YEAR), eCalendar.get(Calendar.MONTH),
                        eCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }

        });


        //Save/Add Course
        btnSvTerm = findViewById(R.id.btnSaveCourse);
        myHelper = new dbHelper(this);
        btnSvTerm.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View vw) {
                try {
                    insertCourses();
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        });


    }

    private void insertCourses() throws ParseException {
        tId = getTermId();

        courseName = findViewById(R.id.txtCourseName);
        cStartDate = findViewById(R.id.txtCourseStartDate);
        cEndDate = findViewById(R.id.txtCourseEndDate);
        status = findViewById(R.id.txtStatus);
        mentorName = findViewById(R.id.txtMentorName);
        mentorPhone = findViewById(R.id.txtMentorPhone);
        mentorEmail = findViewById(R.id.txtMentorEmail);
        notes = findViewById(R.id.txtNotesAdd);


        cName = "" + courseName.getText().toString().trim();
        startD = "" + cStartDate.getText().toString().trim();
        endD = "" + cEndDate.getText().toString().trim();
        cStatus = "" + status.getSelectedItem().toString().trim();
        mentName = "" + mentorName.getText().toString().trim();
        mentPhone = "" + mentorPhone.getText().toString().trim();
        mentEmail = "" + mentorEmail.getText().toString().trim();
        notz = "" + notes.getText().toString().trim();


        //start date vs end date
        SimpleDateFormat format = new SimpleDateFormat("MM/dd/yy");
        Date sdate = format.parse(startD);
        Date edate =format.parse(endD);

        if (sdate.after(edate)){
            Toast.makeText(AddCourse.this, "Start Date cannot be after End Date, please correct.", Toast.LENGTH_SHORT).show();
        }
        else {

            if (cName.isEmpty() || startD.isEmpty() || endD.isEmpty() || cStatus.isEmpty() || mentName.isEmpty() ||
                    mentPhone.isEmpty() || mentEmail.isEmpty()) {
                Toast.makeText(AddCourse.this, "One or more fields are empty, please correct.", Toast.LENGTH_SHORT).show();
            } else {

                try {
                    long id = myHelper.insertCourses(cName, tId, startD, endD, cStatus, mentName, mentPhone, mentEmail, notz); //
                    Toast.makeText(this, "Course:- " + courseName.getText() + " is now added.", Toast.LENGTH_SHORT).show();
                    Intent termInt = new Intent(getApplicationContext(), TermDetail.class);

                    startActivity(termInt);
                    //  finish();

                } catch (Exception e) {
                    e.getMessage();
                }
            }
        }


    }


    private void updateStartLabel() {
        String mysFormat = "MM/dd/yy";
        SimpleDateFormat sdfS = new SimpleDateFormat(mysFormat, Locale.US);

        cStartDate.setText(sdfS.format(sCalendar.getTime()));
    }

    private void updateEndLabel() {
        String myEFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myEFormat, Locale.US);
        cEndDate.setText(sdf.format(eCalendar.getTime()));
    }


    //Home from action bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuItem item = menu.add("Home");
        item.setIcon(R.drawable.ic_baseline_home_24);
        item.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        item.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {

            @Override
            public boolean onMenuItemClick(MenuItem item) {
                Intent in = new Intent(AddCourse.this, MainActivity.class);
                startActivity(in);
                return true;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }


    //back button
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent myIntent = new Intent(AddCourse.this, TermDetail.class);
        startActivityForResult(myIntent, 0);
        return true;
    }


}