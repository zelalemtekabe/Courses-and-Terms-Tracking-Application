package com.example.c196_zelalem_t;

import android.app.ActionBar;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CursorAdapter;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.c196_zelalem_t.Database.dbHelper;
import com.example.c196_zelalem_t.Models.Term;

import java.util.ArrayList;

public  class TermsActivity extends AppCompatActivity   {
    Button btnNewTerm,btnHomeTerms;
    dbHelper myHelper;
    public static ListView termListView;
    ArrayList<Term> termArrayList;
    public static TermAdapter  termAdapter;
    public static Term selectedTerm;

    private CursorAdapter cursorAdapter;

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_terms);


        //  getActionBar().setHomeButtonEnabled(true);

         getSupportActionBar().setTitle("List of Terms");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        termListView = findViewById(R.id.lvTermListView);
        termListView.setAdapter(cursorAdapter);

        myHelper = new dbHelper(this);
        termArrayList = new ArrayList<>();

        termArrayList = myHelper.getTermList();
        termAdapter = new TermAdapter(this, termArrayList);

        loadTermDataToListView();
        termListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long termId) {

              Intent termIntent = new Intent(TermsActivity.this, TermDetail.class);

              selectedTerm =  termArrayList.get(position);
              int id = (int) selectedTerm.getTermId();
              String name = selectedTerm.getTermName();
              String start = selectedTerm.getTermStart();
              String end = selectedTerm.getTermEnd();

                  termIntent.putExtra("termId",id);
                  termIntent.putExtra("termName",name);
                  termIntent.putExtra("start",start);
                  termIntent.putExtra("end",end);
               startActivity(termIntent);

            }

        });


        //btnNewTerm
        btnNewTerm = (Button) findViewById(R.id.btnAddNewTerm);
        btnNewTerm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent termInt = new Intent(getApplicationContext(), AddTerm.class);
                startActivity(termInt);
            }
        });

    }

    //Home from action bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuItem item=menu.add("Home");
        item.setIcon(R.drawable.ic_baseline_home_24);
        item.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        item.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {

            @Override
            public boolean onMenuItemClick(MenuItem item) {
                Intent in = new Intent(TermsActivity.this,MainActivity.class);
                startActivity(in);
                return true;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }

    //back button
    @Override
    public boolean onOptionsItemSelected( MenuItem item) {
        Intent myIntent = new Intent(getApplicationContext(), MainActivity.class);
        startActivityForResult(myIntent, 0);
        return true;
    }

    public static int getTermId() {
        //return String.valueOf(selectedTerm.getTermId());
        return selectedTerm.getTermId();
    }


   public static void loadTermDataToListView() {
            termListView.setAdapter(termAdapter);
            termAdapter.notifyDataSetChanged();
    }
}
