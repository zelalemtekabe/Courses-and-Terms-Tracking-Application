package com.example.c196_zelalem_t.Database;

public class CoursesTable {
    public static final String TABLE_COURSESTABLE= "CoursesTable";
    public static final String COLUMN_ID = "courseId";
    public static final String COLUMN_NAME = "courseName";
    public static final String COLUMN_TERMID = "termId";
    public static final String COLUMN_STARTDATE = "startDate";
    public static final String COLUMN_ENDDATE = "endDate";
    public static final String COLUMN_STATUS ="status";
    public static final String COLUMN_MENTORNAME = "mentorName";
    public static final String COLUMN_MENTORPHONE = "mentorPhone";
    public static final String COLUMN_MENTOREMAIL = "mentorEmail";
    public static final String COLUMN_NOTES = "notes";


    public static final  String createCoursesTable =
            "CREATE TABLE "+ TABLE_COURSESTABLE + "("+ COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_NAME + " TEXT,"
                    + COLUMN_TERMID + " TEXT,"
                    + COLUMN_STARTDATE + " DATE,"
                    + COLUMN_ENDDATE + " DATE,"
                    + COLUMN_STATUS + " TEXT,"
                    + COLUMN_MENTORNAME + " TEXT,"
                    + COLUMN_MENTORPHONE + " TEXT,"
                    + COLUMN_MENTOREMAIL + " TEXT,"
                    + COLUMN_NOTES + " TEXT"
                    +");";

    public static final String deleteCoursesTable =
            "DROP TABLE " + TABLE_COURSESTABLE;
}
