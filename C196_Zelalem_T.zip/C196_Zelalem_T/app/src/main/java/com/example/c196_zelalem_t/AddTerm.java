package com.example.c196_zelalem_t;

import android.app.ActionBar;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.c196_zelalem_t.Database.dbHelper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;

public class AddTerm extends AppCompatActivity {

    DatePickerDialog picker;
    EditText dpStartDate;
    EditText dpEndDate;

    private final static AtomicInteger aId = new AtomicInteger(0);

    final Calendar sCalendar = Calendar.getInstance();
    final Calendar eCalendar = Calendar.getInstance();

    DatePickerDialog.OnDateSetListener sDate;
    DatePickerDialog.OnDateSetListener eDate;

    private EditText termName, startDate, endDate;
    private Button btnSvTerm;
    private dbHelper myHelper;
    private String tId;
    private String tName, startD, endD;

    SQLiteDatabase dBase;
    Button btnHome;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
      //  setContentView(R.layout.activity_add_term);
        setContentView(R.layout.activity_add_term);

        getSupportActionBar().setTitle("Add a new Term");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //Date selection
        startDate = findViewById(R.id.txtStartDate);
        sDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {


                sCalendar.set(Calendar.YEAR, year);
                sCalendar.set(Calendar.MONTH, monthOfYear);
                sCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateStartLabel();
               // sCalendar.clear();//?
            }

        };

        endDate = findViewById(R.id.txtEndDate);
        eDate = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                eCalendar.set(Calendar.YEAR, year);
                eCalendar.set(Calendar.MONTH, monthOfYear);
                eCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateEndLabel();
               // eCalendar.clear();//?
            }

        };

        startDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                new DatePickerDialog(AddTerm.this, sDate, sCalendar
                        .get(Calendar.YEAR), sCalendar.get(Calendar.MONTH),
                        sCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }

        });

        endDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                new DatePickerDialog(AddTerm.this, eDate, eCalendar
                        .get(Calendar.YEAR), eCalendar.get(Calendar.MONTH),
                        eCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }

        });


        termName = findViewById(R.id.txtTermName);
        startDate = findViewById(R.id.txtStartDate);
        endDate = findViewById(R.id.txtEndDate);

        btnSvTerm = findViewById(R.id.btnSaveTerm);
        myHelper = new dbHelper(this);
        btnSvTerm.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View vw) {
                try {
                    insertTerms();
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected( MenuItem item) {
        Intent myIntent = new Intent(getApplicationContext(), TermsActivity.class);
        startActivityForResult(myIntent, 0);
        return true;
    }


    //Home from action bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuItem item=menu.add("Home");
        item.setIcon(R.drawable.ic_baseline_home_24);
        item.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        item.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {

            @Override
            public boolean onMenuItemClick(MenuItem item) {
                Intent in = new Intent(AddTerm.this,MainActivity.class);
                startActivity(in);
                return true;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }


    private void insertTerms() throws ParseException {
        tId = String.valueOf(aId.incrementAndGet());

        tName = "" + termName.getText().toString().trim();
        startD = "" + startDate.getText().toString().trim();
        endD = "" + endDate.getText().toString().trim();

        //start date vs end date
        SimpleDateFormat format = new SimpleDateFormat("MM/dd/yy");
        Date sdate = format.parse(startD);
        Date edate = format.parse(endD);


            if (tName.isEmpty() || tName ==null  || startD.isEmpty() || startD ==null || endD.isEmpty() || endD == null) {
                Toast.makeText(AddTerm.this, "One or more field is empty, please correct.", Toast.LENGTH_SHORT).show();
                // return;
        } else {
                if (sdate.after(edate)) {
                    Toast.makeText(AddTerm.this, "Start Date cannot be after End Date, please correct.", Toast.LENGTH_SHORT).show();

                //   return;
            } else {
                //long id = myHelper.insertTerms(tId, tName, startD, endD);
                long id = myHelper.insertTerms(tName, startD, endD);
                Intent termInt = new Intent(getApplicationContext(), TermsActivity.class);
                startActivity(termInt);
                // Toast.makeText(this, termName.getText()+" is now added.", Toast.LENGTH_SHORT).show();
                termName.getText().clear();
                startDate.getText().clear();
                endDate.getText().clear();
            }
        }
    }

    private void updateStartLabel() {
    String mysFormat = "MM/dd/yy";
    SimpleDateFormat sdfS = new SimpleDateFormat(mysFormat, Locale.US);

    startDate.setText(sdfS.format(sCalendar.getTime()));
}

    private void updateEndLabel() {
        String myEFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myEFormat, Locale.US);
        endDate.setText(sdf.format(eCalendar.getTime()));
    }



}