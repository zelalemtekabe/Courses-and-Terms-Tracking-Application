package com.example.c196_zelalem_t.ui.home;

import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.widget.TextView;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.c196_zelalem_t.Database.dbHelper;
import com.example.c196_zelalem_t.R;

public class HomeViewModel extends ViewModel {

    private MutableLiveData<String> mText;
    TextView txtTerms, txtCourses;
    String termsCount, coursesCount;

    public HomeViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("Terms and Courses Tracker" );
    }

    public LiveData<String> getText() {
        return mText;
    }

}