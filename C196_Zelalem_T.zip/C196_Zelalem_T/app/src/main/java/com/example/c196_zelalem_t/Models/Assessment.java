package com.example.c196_zelalem_t.Models;

import com.example.c196_zelalem_t.AssessmentsActivity;

import java.sql.Timestamp;
import java.util.List;

public class Assessment {

    private int assessmentId;
    private String assessmentType;
    private String assessmentName;
    private String courseId;
//    private String assessmentDate;
    private String startDate;
    private String endDate;
    private String course;

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public Assessment(){

}

    public Assessment(int assessmentId, String assessmentType,String assessmentName, String course,  String startDate, String endDate) {
        this.assessmentId = assessmentId;
        this.assessmentName = assessmentName;
        this.course = course;
//        this.courseId = courseId;
        this.assessmentType = assessmentType;
        this.startDate = startDate;
        this.endDate = endDate;
//        this.assessmentDate = assessmentDate;

    }

    public int getAssessmentId() {
        return assessmentId;
    }

    public void setAssessmentId(int assessmentId) {
        this.assessmentId = assessmentId;
    }

    public String getAssessmentType() {
        return assessmentType;
    }

    public void setAssessmentType(String assessmentType) {
        this.assessmentType = assessmentType;
    }

    public String getAssessmentName() {
        return assessmentName;
    }

    public void setAssessmentName(String assessmentName) {
        this.assessmentName = assessmentName;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }
}

