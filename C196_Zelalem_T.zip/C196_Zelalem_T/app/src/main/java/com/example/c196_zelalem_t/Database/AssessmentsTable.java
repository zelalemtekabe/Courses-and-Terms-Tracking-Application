package com.example.c196_zelalem_t.Database;

public class AssessmentsTable {

    public static final String TABLE_ASSESSMENTSTABLE = "AssessmentsTable";
    public static final String COLUMN_ID = "assessmentId";
    public static final String COLUMN_Type = "assessmentType";
    public static final String COLUMN_AssessmentName = "assessmentName";
    public static final String COLUMN_CourseId = "courseId";
    public static final String COLUMN_COURSE = "course";
    public static final String COLUMN_AssessStart = "startDate";
    public static final String COLUMN_AssessEnd = "endDate";
//    public static final String COLUMN_ASSESSMENTDATE = "assessmentDate";

    public static final  String createAssessmentsTable =
            "CREATE TABLE "+ TABLE_ASSESSMENTSTABLE + "("+ COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_Type + " TEXT,"
                    + COLUMN_AssessmentName + " TEXT,"
                    + COLUMN_CourseId + " TEXT,"
                    + COLUMN_COURSE + " TEXT,"
                    + COLUMN_AssessStart + " TEXT,"
                    + COLUMN_AssessEnd + " TEXT"
//                    + COLUMN_ASSESSMENTDATE + " DATE"
                    +");";

    public static final String deleteAssessmentsTable =
            "DROP TABLE " + TABLE_ASSESSMENTSTABLE;
}
