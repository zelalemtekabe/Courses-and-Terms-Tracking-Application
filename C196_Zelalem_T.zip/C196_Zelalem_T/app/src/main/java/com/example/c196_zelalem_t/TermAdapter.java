package com.example.c196_zelalem_t;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.c196_zelalem_t.Models.Term;

import java.util.ArrayList;

public class TermAdapter extends BaseAdapter {
    Context context;
    ArrayList<Term> termArrayList;

    public TermAdapter(Context context, ArrayList<Term> arrayList) {
        this.context = context;
        this.termArrayList = arrayList;
    }

    @Override
    public int getCount() {
        return this.termArrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return termArrayList.get(position);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
//        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater)context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.term_custom_view,null);
            TextView textView1 = (TextView) convertView.findViewById(R.id.termView1);
            TextView textView2 = (TextView) convertView.findViewById(R.id.termView2);
            TextView textView3 = (TextView) convertView.findViewById(R.id.termView3);

//        }
//        else
//        {
            Term t = termArrayList.get(position);
            textView1.setText(t.getTermName());
            textView2.setText(t.getTermStart());
            textView3.setText(t.getTermEnd());

//        }
        return convertView;
    }




}