package com.example.c196_zelalem_t;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.c196_zelalem_t.Database.dbHelper;
import com.example.c196_zelalem_t.Models.Assessment;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class EditAssessment extends AppCompatActivity {


    final Calendar Cal  = Calendar.getInstance();
    DatePickerDialog.OnDateSetListener dStart,dEnd;

    private EditText   startDate,endDate,assessmentName;

    private Spinner courseName,assementType;
    String cName,assessType,startS,endS,assessmentNameS;

    private dbHelper myHelper, helper;

    Button btnSaveEdit, btnEditAssessment, btnDeleteAssessment;
    public static Assessment selectedAssessment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_assessment);

        getSupportActionBar().setTitle("Assessment Detail");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        AssessmentsActivity aAct = new AssessmentsActivity();
        aAct.loadAssessmentDataToListView();



        //Course spinner
        courseName = findViewById(R.id.txtCourse_AssessmentEdit);
        myHelper = new dbHelper(this);
        int aId = AssessmentsActivity.selectedAssessment.getAssessmentId();
        String coursePosition = myHelper.getSelectedAssessmentItem(aId,3);
        List<String > cList =  myHelper.getCoursesList();
        ArrayAdapter<String> courseAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, cList);
        courseAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        courseName.setAdapter(courseAdapter);
        if (coursePosition != null){
            int spinnerPosition = courseAdapter.getPosition(coursePosition);
            courseName.setSelection(spinnerPosition);

        }


        //assessment type spinner
        assementType = findViewById(R.id.txtAsstType_AssessmentEdit);
        dbHelper assessHelper = new dbHelper(this);
        int assessId = AssessmentsActivity.selectedAssessment.getAssessmentId();
        String typePosition = assessHelper.getSelectedAssessmentItem(assessId,2);

        List<String> typeList = new ArrayList();
        typeList.add("Performance Assessment");
        typeList.add("Objective Assessment");
        ArrayAdapter<String> ad = new ArrayAdapter(this, android.R.layout.simple_spinner_item, typeList);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        assementType.setAdapter(ad);
        if (typePosition != null){
            int spinPosition = ad.getPosition(typePosition);
            assementType.setSelection(spinPosition);
        }


        //populate date
        dbHelper dateHelp = new dbHelper(this);
        int asesId = AssessmentsActivity.selectedAssessment.getAssessmentId();

        //AssessmentName
        assessmentName = findViewById(R.id.txtAssessmentNameEdit);
        assessmentName.setText(assessHelper.getSelectedAssessmentItem(asesId,6));


        //date dropdown
        startDate = findViewById(R.id.txtStartAssessmentEdit);
        endDate = findViewById(R.id.txtEndAssessmentEdit);





        startDate.setText(dateHelp.getSelectedAssessmentItem(asesId,4));
        dStart = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                Cal.set(Calendar.YEAR, year);
                Cal.set(Calendar.MONTH, monthOfYear);
                Cal.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                updateStartDateLabel();
            }
        };

        startDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                new DatePickerDialog(EditAssessment.this, dStart, Cal
                        .get(Calendar.YEAR), Cal.get(Calendar.MONTH),
                        Cal.get(Calendar.DAY_OF_MONTH)).show();
            }
        });


        endDate.setText(dateHelp.getSelectedAssessmentItem(asesId,5));
        dEnd= new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                Cal.set(Calendar.YEAR, year);
                Cal.set(Calendar.MONTH, monthOfYear);
                Cal.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                updateEndDateLabel();
            }
        };

        endDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                new DatePickerDialog(EditAssessment.this, dEnd, Cal
                        .get(Calendar.YEAR), Cal.get(Calendar.MONTH),
                        Cal.get(Calendar.DAY_OF_MONTH)).show();
            }
        });





        //save the edit
        btnSaveEdit = findViewById(R.id.btnSaveAssessmentEdit);
        final TextView saveText = findViewById(R.id.textView42);
        btnSaveEdit.setVisibility(View.INVISIBLE);
//        saveText.setVisibility(View.INVISIBLE);
        btnSaveEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveEditAssessment();
                Toast.makeText(EditAssessment.this,"The Assessment is now updated.",Toast.LENGTH_SHORT).show();
                btnSaveEdit.setVisibility(View.INVISIBLE);
//                saveText.setVisibility(View.INVISIBLE);
                Intent back = new Intent(getApplicationContext(),AssessmentsActivity.class);
                startActivity(back);
                finish();

            }
        });


        //edit assessment
        btnEditAssessment = findViewById(R.id.btnEditAssessment);
        btnEditAssessment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnSaveEdit.setVisibility(View.VISIBLE);
//                saveText.setVisibility(View.VISIBLE);
            }
        });


        //delete assessment
        btnDeleteAssessment = findViewById(R.id.btnDeleteAssessment);
        btnDeleteAssessment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                deleteAssessment();
            }
        });

    }





    public void deleteAssessment(){
        int aId = AssessmentsActivity.selectedAssessment.getAssessmentId();
        try {

            helper = new dbHelper(EditAssessment.this);
            SQLiteDatabase db;
            db = helper.getWritableDatabase();
            db.execSQL("DELETE FROM AssessmentsTable WHERE assessmentId = " + aId);
            db.close();
            Toast.makeText(this, "The Assessment is now deleted.", Toast.LENGTH_SHORT).show();


            Intent delIntent = new Intent(EditAssessment.this,AssessmentsActivity.class);
            startActivity(delIntent);

        } catch (SQLException e) {
            e.getStackTrace();
        }

    }
    public void saveEditAssessment() {
        try {
            int assessmentId = AssessmentsActivity.selectedAssessment.getAssessmentId();


            assessmentNameS = "" + assessmentName.getText().toString().trim();
            assessType = "" + assementType.getSelectedItem().toString().trim();
            cName = "" + courseName.getSelectedItem().toString().trim();
            startS = "" + startDate.getText().toString().trim();
            endS = "" + endDate.getText().toString().trim();

           // int crsId = AssessmentsActivity.selectedAssessment.getCourseId();
            dbHelper help = new dbHelper(this);
            int  crsId = help.courseId(cName);
            helper = new dbHelper(EditAssessment.this);

            SQLiteDatabase db;
            db = helper.getWritableDatabase();
            db.execSQL("UPDATE AssessmentsTable SET assessmentType = " + "'" + assessType  + "'"
                    + ", assessmentName = " + "'" + assessmentNameS + "'"
                    + ", course = " + "'" + cName + "'"
                    + ", courseId = "+  crsId
                    + ", startDate = " + "'" + startS + "'"
                    + ", endDate = " + "'" + endS + "'"
                    + " WHERE assessmentId = " + assessmentId);
            db.close();
            Toast.makeText(this, "The Assessment is now updated.", Toast.LENGTH_SHORT).show();
        } catch (SQLException e) {
            e.getStackTrace();
        }
    }


    //Home from action bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuItem item=menu.add("Home");
        item.setIcon(R.drawable.ic_baseline_home_24);
        item.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        item.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {

            @Override
            public boolean onMenuItemClick(MenuItem item) {
                // TODO Auto-generated method stub
                Intent in = new Intent(EditAssessment.this,MainActivity.class);
                startActivity(in);
                return true;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected( MenuItem item) {
        Intent myIntent = new Intent(getApplicationContext(), AssessmentsActivity.class);
        startActivityForResult(myIntent, 0);
        return true;
    }

    private void updateStartDateLabel() {
        String mysFormat = "MM/dd/yy";
        SimpleDateFormat sdfS = new SimpleDateFormat(mysFormat, Locale.US);

        startDate.setText(sdfS.format(Cal.getTime()));
    }
    private void updateEndDateLabel() {
        String mysFormat = "MM/dd/yy";
        SimpleDateFormat sdfS = new SimpleDateFormat(mysFormat, Locale.US);

        endDate.setText(sdfS.format(Cal.getTime()));
    }

}