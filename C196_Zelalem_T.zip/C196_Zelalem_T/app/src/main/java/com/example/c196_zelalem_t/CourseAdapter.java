package com.example.c196_zelalem_t;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.c196_zelalem_t.Models.Course;

import java.util.ArrayList;

public class CourseAdapter extends BaseAdapter {
    Context context;
    ArrayList<Course> courseArrayList;

    public CourseAdapter(Context context, ArrayList<Course> arrayList) {
        this.context = context;
        this.courseArrayList = arrayList;
    }


    @Override
    public int getCount() {
        return this.courseArrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return courseArrayList.get(position);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        LayoutInflater inflater = (LayoutInflater)context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        convertView = inflater.inflate(R.layout.course_custom_view,null);
        TextView courseName = (TextView) convertView.findViewById(R.id.cvCourseName);
        TextView courseStart = (TextView) convertView.findViewById(R.id.cvCourseStart);
        TextView courseEnd = (TextView) convertView.findViewById(R.id.cvCourseEnd);

        Course cr = courseArrayList.get(position);
        courseName.setText(cr.getCourseName());
        courseStart.setText(cr.getStartDate());
        courseEnd.setText(cr.getEndDate());

        return convertView;
    }
}
