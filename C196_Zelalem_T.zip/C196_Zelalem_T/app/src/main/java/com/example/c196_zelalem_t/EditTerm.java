package com.example.c196_zelalem_t;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import com.example.c196_zelalem_t.Database.dbHelper;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import static com.example.c196_zelalem_t.TermsActivity.getTermId;

public class EditTerm extends AppCompatActivity {
    TextView editTermName, editStartDate, editEndDate;
    TextView editTermName1, editStartDate2, editEndDate3;
    String edTermName, edStartDate, edEndDate;

    Button btnSaveEditTerm;
    final Calendar sCalendar = Calendar.getInstance();
    final Calendar eCalendar = Calendar.getInstance();
    DatePickerDialog.OnDateSetListener sDate;
    DatePickerDialog.OnDateSetListener eDate;

    dbHelper helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_term);

        getSupportActionBar().setTitle("Edit Term");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //Start and End dates
        editStartDate = findViewById(R.id.txtEditStartDate);
        sDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                sCalendar.set(Calendar.YEAR, year);
                sCalendar.set(Calendar.MONTH, monthOfYear);
                sCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateStartLabel();
                sCalendar.clear();//?
            }

        };

        editEndDate = findViewById(R.id.txtEditEndDate);
        eDate = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                eCalendar.set(Calendar.YEAR, year);
                eCalendar.set(Calendar.MONTH, monthOfYear);
                eCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateEndLabel();
                eCalendar.clear();//?
            }

        };

        editStartDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                new DatePickerDialog(EditTerm.this, sDate, sCalendar
                        .get(Calendar.YEAR), sCalendar.get(Calendar.MONTH),
                        sCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }

        });

        editEndDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                new DatePickerDialog(EditTerm.this, eDate, eCalendar
                        .get(Calendar.YEAR), eCalendar.get(Calendar.MONTH),
                        eCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }

        });

        //set text for edit

        editTermName = findViewById(R.id.txtEditTermName);
        editStartDate = findViewById(R.id.txtEditStartDate);
        editEndDate = findViewById(R.id.txtEditEndDate);

        Bundle edBundle = getIntent().getExtras();

        if (edBundle != null) {
            //    tID.setText(bundle.getString("termId"));
            editTermName.setText(edBundle.getString("termName"));
            editStartDate.setText(edBundle.getString("start"));
            editEndDate.setText(edBundle.getString("end"));
        }


        //Save Edit
        btnSaveEditTerm = (Button) findViewById(R.id.btnEditSaveTerm);
        btnSaveEditTerm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                saveEditTerm();
                TermsActivity.loadTermDataToListView();

                Intent e = new Intent(getApplicationContext(), TermsActivity.class);
                startActivity(e);
            }
        });
    }


    //Home from action bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuItem item = menu.add("Home");
        item.setIcon(R.drawable.ic_baseline_home_24);
        item.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        item.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {

            @Override
            public boolean onMenuItemClick(MenuItem item) {
                // TODO Auto-generated method stub
                Intent in = new Intent(EditTerm.this, MainActivity.class);
                startActivity(in);
                return true;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent myIntent = new Intent(getApplicationContext(), TermsActivity.class);
        startActivityForResult(myIntent, 0);
        return true;

    }


    private void updateStartLabel() {
        String mysFormat = "MM/dd/yy";
        SimpleDateFormat sdfS = new SimpleDateFormat(mysFormat, Locale.US);

        editStartDate.setText(sdfS.format(sCalendar.getTime()));
    }

    private void updateEndLabel() {
        String myEFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myEFormat, Locale.US);
        editEndDate.setText(sdf.format(eCalendar.getTime()));
    }

    public void saveEditTerm() {
        try {
            int teID = getTermId();

            edTermName = "" + editTermName.getText().toString().trim();
            edStartDate = "" + editStartDate.getText().toString().trim();
            ;
            edEndDate = "" + editEndDate.getText().toString().trim();
            ;

            helper = new dbHelper(EditTerm.this);

            SQLiteDatabase db;
            db = helper.getWritableDatabase();
            db.execSQL("UPDATE TermTable SET termName = " + "'" + edTermName + "'"
                    + ", termStart = " + "'" + edStartDate + "'"
                    + ", termEnd = " + "'" + edEndDate + "'"
                    + " WHERE termId = " + teID);
            db.close();
            Toast.makeText(this, "The term is now updated.", Toast.LENGTH_SHORT).show();
        } catch (SQLException e) {
            e.getStackTrace();
        }
    }


}