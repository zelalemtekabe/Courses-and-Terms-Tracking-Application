package com.example.c196_zelalem_t.Database;

public class NoteTable {
    public static final String TABLE_NOTETABLE = "NoteTable";
    public static final String COLUMN_ID = "noteId";
    public static final String COLUMN_NOTETITLE = "noteTitle";
    public static final String COLUMN_COURSEID = "courseId";

    public static final  String createNoteTable =
            "CREATE TABLE "+ TABLE_NOTETABLE + "("+ COLUMN_ID + " TEXT PRIMARY KEY,"
                    + COLUMN_NOTETITLE + " TEXT,"
                    + COLUMN_COURSEID + " TEXT"

                    +");";

    public static final String deleteNoteTable =
            "DROP TABLE " + TABLE_NOTETABLE;

}
