package com.example.c196_zelalem_t.Database;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class DBProvider extends ContentProvider {

    //path strings
    private static final String AUTHORITY = "com.example.c196_zelalem_t.DBProvider";
    private static final String TERMS_PATH = "terms";


    //URSLs
    public static final Uri TERMS_URI = Uri.parse("content://" + AUTHORITY + "/" + TERMS_PATH);


    //Constants
    private static final int TERMS = 1;
    private static final int TERMS_ID = 2;
    private static final int COURSES = 3;


    //URI Matcher
    private static final UriMatcher uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);

    static {
        uriMatcher.addURI(AUTHORITY, TERMS_PATH, TERMS);
        uriMatcher.addURI(AUTHORITY, TERMS_PATH + "/#", TERMS_ID);


    }


    public static final String TERM_CONTENT_TYPE = "term";
    public static final String COURSE_CONTENT_TYPE = "course";
    public static final String COURSE_NOTE_CONTENT_TYPE = "courseNote";
    public static final String ASSESSMENT_CONTENT_TYPE = "assessment";
    public static final String ASSESSMENT_NOTE_CONTENT_TYPE = "assessmentNote";



    private SQLiteDatabase db;

    @Override
    public boolean onCreate() {
        dbHelper helper = new dbHelper(getContext());
        db = helper.getWritableDatabase();
        return true;
    }

    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] projection, @Nullable String selection, @Nullable String[] selectionArgs, @Nullable String sortOrder) {
        switch (uriMatcher.match(uri)) {
            case TERMS:
                return db.query(TermTable.TABLE_TERMTABLE, TermTable.TABLE_COLUMNS, selection, null,
                        null, null, TermTable.COLUMN_ID + "DESC");


//MORE TO COME HERE


            default:
                throw new IllegalArgumentException("invalid URI" + uri);

        }


    }

    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        return null;
    }

    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues contentValues) {
        long id;
        switch (uriMatcher.match(uri)) {
            case TERMS:
                id = db.insert(TermTable.TABLE_TERMTABLE, null, contentValues);
                return uri.parse(TERMS_PATH + "/" + id);



            default:
                throw new IllegalArgumentException("Invalid URI:" + uri);

        }
    }

    @Override
    public int delete(@NonNull Uri uri, @Nullable String selection, @Nullable String[] selectionArgs) {
        switch (uriMatcher.match(uri)) {
            case TERMS:
                return db.delete(TermTable.TABLE_TERMTABLE, selection, selectionArgs);


            default:
                throw new IllegalArgumentException("Invalid URI:" + uri);

        }
    }

    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues contentValues, @Nullable String selection, @Nullable String[] selectionArgs) {
        switch (uriMatcher.match(uri)) {
            case TERMS:
                return db.update(TermTable.TABLE_TERMTABLE, contentValues, selection, selectionArgs);


            default:
                throw new IllegalArgumentException("Invalid URI:" + uri);
        }
    }
}
