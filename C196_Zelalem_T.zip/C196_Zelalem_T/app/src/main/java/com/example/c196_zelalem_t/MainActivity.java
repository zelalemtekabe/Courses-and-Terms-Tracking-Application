package com.example.c196_zelalem_t;


import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.format.DateUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.c196_zelalem_t.Database.dbHelper;
import com.example.c196_zelalem_t.Models.Assessment;
import com.example.c196_zelalem_t.Models.Course;
import com.example.c196_zelalem_t.Models.Term;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;

import androidx.core.app.ActivityCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;

    Button btnAssessments, btnTerms;
    dbHelper helper;
    DrawerLayout drawer;

    public ListView summaryListView;
    public ArrayList<Course> summaryArrayList;
    public CourseAdapter summaryAdapter;
    public dbHelper myHelper;
    private List<Term> termList = new ArrayList<>();
    private List<Course> courseList = new ArrayList<>();
    private List<Assessment> assessmentList = new ArrayList<>();
    private TextView courseStatus;

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.SEND_SMS, Manifest.permission.READ_SMS},
                PackageManager.PERMISSION_GRANTED);


//        FloatingActionButton fab = findViewById(R.id.fab);
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
//            }
//        });


        try {
            notifications();
//            assessmentNotifications();
        } catch (Exception e) {
            e.toString();
        }

        courseStatus = findViewById(R.id.txtNrOfCourses);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_terms, R.id.nav_courses)
                .setDrawerLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


    //delete all courses
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_delete_all_terms) {
            deleteAllTerms();

            return true;
        } else if (id == R.id.action_delete_all_courses) {
            deleteAllCourses();
            return true;
        } else if (id == R.id.action_delete_all_assessments) {
            deleteAllAssessments();

            return true;
        } else if (id == R.id.action_insert_sample_data) {
            insertSampleData();

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void deleteAllCourses() {
        try {
            helper = new dbHelper(MainActivity.this);
            SQLiteDatabase db;
            db = helper.getWritableDatabase();
            db.execSQL("DELETE FROM CoursesTable ");
            db.close();
            Intent refC = new Intent(MainActivity.this, MainActivity.class);
            startActivity(refC);
            Toast.makeText(this, "All Courses are now deleted.", Toast.LENGTH_SHORT).show();
        } catch (SQLException ex) {
            ex.getStackTrace();
            ex.getMessage();
        }
    }

    public void deleteAllTerms() {

        if (hasACourse()) {
            Toast.makeText(MainActivity.this, "Cannot delete, there is one or more course associated to a term.", Toast.LENGTH_SHORT).show();
        } else
            try {
                helper = new dbHelper(MainActivity.this);
                SQLiteDatabase db;
                db = helper.getWritableDatabase();
                db.execSQL("DELETE FROM TermTable ");
                db.close();
                Toast.makeText(this, "All Terms are now deleted.", Toast.LENGTH_SHORT).show();
                Intent refT = new Intent(MainActivity.this, MainActivity.class);
                startActivity(refT);
            } catch (SQLException ex) {
                ex.getStackTrace();
                ex.getMessage();
            }
    }

    public void deleteAllAssessments() {
        try {
            helper = new dbHelper(MainActivity.this);
            SQLiteDatabase db;
            db = helper.getWritableDatabase();
            db.execSQL("DELETE FROM AssessmentsTable ");
            db.close();
            Toast.makeText(this, "All Assessments are now deleted.", Toast.LENGTH_SHORT).show();
            Intent refA = new Intent(MainActivity.this, MainActivity.class);
            startActivity(refA);
        } catch (SQLException ex) {
            ex.getStackTrace();
            ex.getMessage();
        }
    }

    public void insertSampleData() {
        try {
            helper = new dbHelper(MainActivity.this);
            SQLiteDatabase db;
            db = helper.getWritableDatabase();
            db.execSQL("INSERT INTO TermTable (termId, termName, termStart,termEnd) " +
                    " VALUES (1,'Term One - 2020', '08/01/20','10/30/20') ");

            db.execSQL(" INSERT INTO TermTable (termId, termName, termStart,termEnd) " +
                    " VALUES (2,'Term Two - 2020', '11/01/20','01/30/21')");

            db.execSQL("INSERT INTO CoursesTable (courseName,termId,startDate,endDate,status,mentorName,mentorPhone,mentorEmail,notes)" +
                    "VALUES ('Software I', 1, '08/01/20','10/30/20','In Progress','MyMentor1','00000','mentoremail1@example.com','We will be building an application in NetBeans.')");

            db.execSQL("INSERT INTO CoursesTable (courseName,termId,startDate,endDate,status,mentorName,mentorPhone,mentorEmail,notes)" +
                    " VALUES ('Software II', 1, '11/01/20','01/30/21','Plan to take','MyMentor2','11111','mentoremail2@example.com','Software II will delve into advanced concepts in Java.')");

            db.execSQL("INSERT INTO CoursesTable (courseName,termId,startDate,endDate,status,mentorName,mentorPhone,mentorEmail,notes)" +
                    "VALUES ('Capstone', 2, '11/01/2020','01/30/21','Dropped','MyMentor3','22222','mentoremail3@example.com','Excited.')");

            db.execSQL("INSERT INTO AssessmentsTable (assessmentType,assessmentName,courseId,course,startDate,endDate)" +
                    " VALUES ('Objective Assessment','First Assessment',1,'Software I','10/30/20','11/01/20');");

            db.close();
            Toast.makeText(this, "Sample data inserted.", Toast.LENGTH_SHORT).show();
            Intent refA = new Intent(MainActivity.this, MainActivity.class);
            startActivity(refA);
        } catch (SQLException ex) {
            ex.getStackTrace();
            ex.getMessage();
        }

    }


    public boolean hasACourse() {
        helper = new dbHelper(MainActivity.this);
        SQLiteDatabase db;
        db = helper.getWritableDatabase();
        String Q = "SELECT * FROM CoursesTable ";
        Cursor cursor = db.rawQuery(Q, null);
        // db.close();
        if (cursor.getCount() <= 0) {
            cursor.close();
            return false;
        } else {
            cursor.close();
            return true;
        }
    }


    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

    private void notifications() throws Exception {

        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yy");

        dbHelper dHelper = new dbHelper(this);
        ArrayList<Course> crs = dHelper.getCoursesDueToday();

    for (Course course : crs) {
        if (DateUtils.isToday(formatter.parse(course.getStartDate()).getTime())) {
            Toast.makeText(MainActivity.this, "Yay your course " + "'" + course.getCourseName() + "'" + " started today.", Toast.LENGTH_LONG).show();
        }
        if (DateUtils.isToday(formatter.parse(course.getEndDate()).getTime())) {
            Toast.makeText(MainActivity.this, "Your course " + "'" + course.getCourseName() + "'" + " ends today.", Toast.LENGTH_LONG).show();
        }

}


        ArrayList<Assessment> assess = dHelper.getAssessmentsDueToday();

    for (Assessment asment : assess) {
        if (DateUtils.isToday(formatter.parse(asment.getStartDate()).getTime())) {
            Toast.makeText(MainActivity.this, "Your assessment " + "'" + asment.getAssessmentName() + "'" + " starts today.", Toast.LENGTH_LONG).show();
        }
        if (DateUtils.isToday(formatter.parse(asment.getEndDate()).getTime())) {
            Toast.makeText(MainActivity.this, "Your assessment " + "'" + asment.getAssessmentName() + "'" + " is due today.", Toast.LENGTH_LONG).show();

        }

    }


    }

//    private void assessmentNotifications() throws Exception {
//
//        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yy");
//
//        dbHelper dHelper = new dbHelper(this);
//        ArrayList<Assessment> assess = dHelper.getAssessmentsDueToday();
//        for (Assessment asment : assess) {
//            if (DateUtils.isToday(formatter.parse(asment.getStartDate()).getTime())) {
//                Toast.makeText(MainActivity.this, "Your assessment for course: " + asment.getCourse() + " is today.", Toast.LENGTH_LONG).show();
//            }
//            if (DateUtils.isToday(formatter.parse(asment.getEndDate()).getTime())) {
//                Toast.makeText(MainActivity.this, "Your assessment for course: " + asment.getCourse() + " is due today.", Toast.LENGTH_LONG).show();
//
//            }
//
//
//        }
//    }
}





