package com.example.c196_zelalem_t;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.c196_zelalem_t.Models.Assessment;
import com.example.c196_zelalem_t.Models.Course;
import com.example.c196_zelalem_t.R;

import java.util.ArrayList;

public class AssessmentAdapter extends BaseAdapter {
    Context context;
    ArrayList<Assessment> assessmentArrayList;

    public AssessmentAdapter(Context context, ArrayList<Assessment> arrayList) {
        this.context = context;
        this.assessmentArrayList = arrayList;
    }


    @Override
    public int getCount() {
        return this.assessmentArrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return assessmentArrayList.get(position);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        LayoutInflater inflater = (LayoutInflater)context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        convertView = inflater.inflate(R.layout.assessment_custom_view,null);
//        TextView courseName = (TextView) convertView.findViewById(R.id.lvCourse_assessment);
        TextView assessmentName = (TextView) convertView.findViewById(R.id.lvCourse_assessment);
        TextView dateS = (TextView) convertView.findViewById(R.id.lvAssessStart);
        TextView dateE = (TextView) convertView.findViewById(R.id.lvAssessEnd);
        TextView assessType = (TextView) convertView.findViewById(R.id.lvAssesmentType);

        Assessment cr = assessmentArrayList.get(position);
        assessmentName.setText(cr.getAssessmentName());
        dateS.setText(cr.getStartDate());
        dateE.setText(cr.getEndDate());
        assessType.setText(cr.getAssessmentType());


        return convertView;
    }
}
