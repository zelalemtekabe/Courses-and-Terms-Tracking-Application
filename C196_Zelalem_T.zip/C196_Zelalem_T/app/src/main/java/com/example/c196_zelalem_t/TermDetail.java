package com.example.c196_zelalem_t;

import android.app.ActionBar;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.c196_zelalem_t.Database.dbHelper;
import com.example.c196_zelalem_t.Models.Course;
import com.example.c196_zelalem_t.Models.Term;

import java.util.ArrayList;

import static com.example.c196_zelalem_t.TermsActivity.getTermId;
import static com.example.c196_zelalem_t.TermsActivity.selectedTerm;


public class TermDetail extends AppCompatActivity {
   public TextView tID, termName, startDate, endDate;
    public dbHelper helper;
    public long termId;
    public Button btnNewCourse, btnEditTerm, btnDeleteTerm;

    //
    ListView courseListView;
    ArrayList<Course> courseArrayList;
    CourseAdapter courseAdapter;
    dbHelper myHelper;

    public static Course selectedCourse;

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_term_detail);

        getSupportActionBar().setTitle("Terms Detail");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
       //Intent intent = getIntent();

       //getActionBar().setHomeButtonEnabled(true);


        termName = findViewById(R.id.lblTermName_tDetail);
        startDate = findViewById(R.id.lblStartDate_tDetail);
        endDate =  findViewById(R.id.lblEndDate_tDetail);
        Bundle bundle = getIntent().getExtras();
      if (bundle != null) {
            //    tID.setText(bundle.getString("termId"));
            termName.setText(bundle.getString("termName" ));
            startDate.setText(bundle.getString("start" ));
            endDate.setText(bundle.getString("end" ));
        }


        myHelper = new dbHelper(this);
        loadCourseDataToListView();


        //btnNewCourse
        btnNewCourse = (Button) findViewById(R.id.btnAddCourse);
        btnNewCourse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent courseInt = new Intent(getApplicationContext(), AddCourse.class);
                startActivity(courseInt);
            }
        });


        // open course detail activity
        courseListView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Intent courseIntent = new Intent(getApplicationContext(), CourseDetail.class);
                selectedCourse = courseArrayList.get(position);;

                String termName = selectedTerm.getTermName();
                String termStart  = selectedTerm.getTermStart();
                String termEnd = selectedTerm.getTermEnd();

                String courseName = selectedCourse.getCourseName();
                String coursStart = selectedCourse.getStartDate();
                String courseEnd = selectedCourse.getEndDate();
                String status = selectedCourse.getStatus();
                String mentor = selectedCourse.getMentorName();
                String phone = selectedCourse.getMentorPhone();
                String email = selectedCourse.getMentorEmail();
                String notes = selectedCourse.getNotes();

                courseIntent.putExtra("termName",termName);
                courseIntent.putExtra("start",termStart);
                courseIntent.putExtra("end",termEnd);

                courseIntent.putExtra("courseName",courseName);
                courseIntent.putExtra("coursStart",coursStart);
                courseIntent.putExtra("courseEnd",courseEnd);
                courseIntent.putExtra("status",status);
                courseIntent.putExtra("mentor",mentor);
                courseIntent.putExtra("phone",phone);
                courseIntent.putExtra("email",email);
                courseIntent.putExtra("notes",notes);

                startActivity(courseIntent);
            }
        });




        //btnDeleteTerm
        btnDeleteTerm = (Button) findViewById(R.id.btnDeleteTerm);
        btnDeleteTerm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                deleteTerm();

            }
        });

        //btnEditTerm
        btnEditTerm = (Button) findViewById(R.id.btnEditTerm);
        btnEditTerm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent editInt = new Intent(getApplicationContext(), EditTerm.class);
                String name = selectedTerm.getTermName();
                String start = selectedTerm.getTermStart();
                String end = selectedTerm.getTermEnd();



                editInt.putExtra("termName",name);
                editInt.putExtra("start",start);
                editInt.putExtra("end",end);


                startActivity(editInt);
            }
        });

    }

    //Home from action bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuItem item=menu.add("Home");
        item.setIcon(R.drawable.ic_baseline_home_24);
        item.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        item.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {

            @Override
            public boolean onMenuItemClick(MenuItem item) {
                // TODO Auto-generated method stub
                Intent in = new Intent(TermDetail.this,MainActivity.class);
                startActivity(in);
                return true;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }

    public  void loadCourseDataToListView() {
        try {
            int gId = getTermId();
            courseListView = findViewById(R.id.lvCoursesView);

            courseArrayList = myHelper.getCoursesList(gId);
            courseAdapter = new CourseAdapter(this, courseArrayList);
            courseListView.setAdapter(courseAdapter);
            courseAdapter.notifyDataSetChanged();
        } catch (Exception e) {
            e.toString();
        }
    }

    public void deleteTerm() {
        int teID = getTermId();

        if (hasCourse(teID)) {
            Toast.makeText(this, "The term cannot be deleted, there is a course associated to it.", Toast.LENGTH_SHORT).show();
        } else {
            try {

                helper = new dbHelper(TermDetail.this);
                SQLiteDatabase db;
                db = helper.getWritableDatabase();
                db.execSQL("DELETE FROM TermTable WHERE termId = " + teID);
                db.close();
                Toast.makeText(this, "The term is now deleted.", Toast.LENGTH_SHORT).show();

                TermsActivity.loadTermDataToListView();
                Intent sInt = new Intent(getApplicationContext(), TermsActivity.class);
                startActivity(sInt);

            } catch (SQLException e) {
                e.getStackTrace();
            }
        }
    }


    public  boolean hasCourse(int termId){
         helper = new dbHelper(TermDetail.this);
        SQLiteDatabase db;
        db = helper.getWritableDatabase();
        String Q = "SELECT * FROM TermTable t " +
                " JOIN CoursesTable c " +
                " ON t.termId = c.termId "+
                " WHERE t.termId = " + termId;
        Cursor cursor = db.rawQuery(Q,null);
       // db.close();
        if(cursor.getCount()<=0) {
            cursor.close();
            return false;
        }
        else
        {
            cursor.close();
            return true;
        }
    }


    @Override
    public boolean onOptionsItemSelected( MenuItem item) {
        Intent myIntent = new Intent(getApplicationContext(), TermsActivity.class);
        startActivityForResult(myIntent, 0);
        return true;
    }



}