package com.example.c196_zelalem_t.Database;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.example.c196_zelalem_t.CourseDetail;
import com.example.c196_zelalem_t.MainActivity;
import com.example.c196_zelalem_t.Models.Assessment;
import com.example.c196_zelalem_t.Models.Course;
import com.example.c196_zelalem_t.Models.Term;
import com.example.c196_zelalem_t.R;
import com.example.c196_zelalem_t.TermDetail;
import com.example.c196_zelalem_t.ui.home.HomeViewModel;

import java.lang.reflect.Array;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class dbHelper extends SQLiteOpenHelper {
    private static final String DB_FILE_NAME = "database2.db";
    private static final int DB_VERSION = 1;
    private SQLiteDatabase dbs;
    public dbHelper helper;

    //creates the database
    SQLiteDatabase db = getWritableDatabase();

    public dbHelper(Context context) {
        super(context, DB_FILE_NAME, null, DB_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(AssessmentsTable.createAssessmentsTable);
        db.execSQL(CoursesTable.createCoursesTable);
        db.execSQL(NoteTable.createNoteTable);
        db.execSQL(TermTable.createTermTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase dbs, int oldVersion, int newVersion) {
        dbs.execSQL(AssessmentsTable.deleteAssessmentsTable);
        dbs.execSQL(CoursesTable.deleteCoursesTable);
        dbs.execSQL(NoteTable.deleteNoteTable);
        dbs.execSQL(TermTable.deleteTermTable);
        onCreate(dbs);
    }

    //Courses
    public long insertCourses(String courseName, int termId, String startDate
            , String endDate, String status, String mentorName, String mentorPhone
            , String mentorEmail, String notes) {
        SQLiteDatabase cDb = this.getWritableDatabase();
        ContentValues courseValue = new ContentValues();
        // courseValue.put(String.valueOf(CoursesTable.COLUMN_ID), courseId);
        courseValue.put(CoursesTable.COLUMN_NAME, courseName);
        courseValue.put(String.valueOf(CoursesTable.COLUMN_TERMID), termId);
        courseValue.put(CoursesTable.COLUMN_STARTDATE, startDate);
        courseValue.put(CoursesTable.COLUMN_ENDDATE, endDate);
        courseValue.put(CoursesTable.COLUMN_STATUS, status);
        courseValue.put(CoursesTable.COLUMN_MENTORNAME, mentorName);
        courseValue.put(CoursesTable.COLUMN_MENTORPHONE, mentorPhone);
        courseValue.put(CoursesTable.COLUMN_MENTOREMAIL, mentorEmail);
        courseValue.put(CoursesTable.COLUMN_NOTES, notes);

        long longCourseId = cDb.insert(CoursesTable.TABLE_COURSESTABLE, null, courseValue);
        cDb.close();
        return longCourseId;
    }

    //Terms
    public long insertTerms(String termName, String termStart, String termEnd) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues termValue = new ContentValues();
        // termValue.put(String.valueOf(TermTable.COLUMN_ID), termId);
        termValue.put(TermTable.COLUMN_NAME, termName);
        termValue.put(TermTable.COLUMN_TERMSTART, termStart);
        termValue.put(TermTable.COLUMN_TERMEND, termEnd);

        long longTermId = db.insert(TermTable.TABLE_TERMTABLE, null, termValue);
        db.close();
        return longTermId;
    }


    //assessment String asstId,
    public long insertAssessment(String assessmentType, String assessmentName, int courseId, String course
            , String startDate, String endDate) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues assesValue = new ContentValues();
        // assesValue.put(AssessmentsTable.COLUMN_ID, asstId);
        assesValue.put(AssessmentsTable.COLUMN_Type, assessmentType);
        assesValue.put(AssessmentsTable.COLUMN_AssessmentName, assessmentName);
        assesValue.put(AssessmentsTable.COLUMN_CourseId, courseId);
        assesValue.put(AssessmentsTable.COLUMN_COURSE, course);
        assesValue.put(AssessmentsTable.COLUMN_AssessStart, startDate);
        assesValue.put(AssessmentsTable.COLUMN_AssessEnd, endDate);

//        assesValue.put(AssessmentsTable.COLUMN_ASSESSMENTDATE, assessmentDate);

        long longId = db.insert(AssessmentsTable.TABLE_ASSESSMENTSTABLE, null, assesValue);
        db.close();
        return longId;
    }

    public ArrayList<Term> getTermList() {
        ArrayList<Term> termList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM TermTable", null);
        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String termName = cursor.getString(1);
            String termStart = cursor.getString(2);
            String termEnd = cursor.getString(3);
            Term term = new Term(id, termName, termStart, termEnd);
            termList.add(term);
            db.close();//??
        }
        return termList;
    }

    public List<String> getCoursesList() {
        List<String> courseList = new ArrayList<String>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT courseId, courseName,startDate,endDate FROM CoursesTable", null);
        while (cursor.moveToNext()) {
            courseList.add(cursor.getString(cursor.getColumnIndex("courseName")));
            db.close();//??
        }
        return courseList;
    }


    public ArrayList<Course> getCoursesDueToday() throws Exception {
        ArrayList<Course> courseList = new ArrayList<>();
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yy");
        Date today = new Date();
        String start = formatter.format(today);
        String end = formatter.format(today);

//
//        ArrayList<String> cr = new ArrayList<String>();
        SQLiteDatabase db = this.getReadableDatabase();
        try {
            Cursor cursor = db.rawQuery("SELECT courseId, courseName,startDate,endDate,status FROM CoursesTable" +
                    " WHERE startDate = " + "'" + start + "'" + " OR " + " endDate = " + "'" + end + "'", null);
            while (cursor.moveToNext()) {
                int cid = cursor.getInt(0);
                String courseName = cursor.getString(1);
                String courseStart = cursor.getString(2);
                String courseEnd = cursor.getString(3);
                String status = cursor.getString(4);
                Course course = new Course(cid, courseName, courseStart, courseEnd, status);
                courseList.add(course);
                db.close();//??

            }
        } catch (SQLException E) {
            E.getStackTrace();
        }
        return courseList;
    }


    public ArrayList<Assessment> getAssessmentsDueToday() throws Exception {
        ArrayList<Assessment> assessmentsList = new ArrayList<>();
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yy");
        Date today = new Date();
        String start = formatter.format(today);
        String end = formatter.format(today);

//
//        ArrayList<String> cr = new ArrayList<String>();
        SQLiteDatabase db = this.getReadableDatabase();
        try {
            Cursor cursor = db.rawQuery("SELECT assessmentId, assessmentType, assessmentName,course,startDate,endDate FROM AssessmentsTable" +
                    " WHERE startDate = " + "'" + start + "'" + " OR " + " endDate = " + "'" + end + "'", null);
            while (cursor.moveToNext()) {
                int cid = cursor.getInt(0);
                String assessmentType = cursor.getString(1);
                String assessmentName = cursor.getString(2);
//                String courseId = cursor.getString(2);
                String course = cursor.getString(3);
                String startDate = cursor.getString(4);
                String endDate = cursor.getString(5);
                Assessment assessment = new Assessment(cid, assessmentType, assessmentName, course, startDate, endDate);
                assessmentsList.add(assessment);
                db.close();//??

            }
        } catch (SQLException E) {
            E.getStackTrace();
        }
        return assessmentsList;
    }


    public ArrayList<Course> getCoursesList(int tmId) {
        ArrayList<Course> courseList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        try {
            Cursor cursor = db.rawQuery("SELECT courseId, courseName, startDate, endDate, status FROM CoursesTable WHERE termId =" + tmId, null);
            while (cursor.moveToNext()) {
                int cid = cursor.getInt(0);
                String courseName = cursor.getString(1);
                String courseStart = cursor.getString(2);
                String courseEnd = cursor.getString(3);
                String status = cursor.getString(4);
                Course course = new Course(cid, courseName, courseStart, courseEnd, status);
                courseList.add(course);
                db.close();//??
            }
        } catch (SQLException E) {
            E.getStackTrace();
        }
        return courseList;
    }


    public ArrayList<Assessment> getAssessmentsList() {
        ArrayList<Assessment> assessmentsList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        try {
            Cursor cursor = db.rawQuery("select assessmentId, course, assessmentType ,assessmentName, startDate, endDate from AssessmentsTable", null);
            while (cursor.moveToNext()) {
                int aId = cursor.getInt(0);
                String courseName = cursor.getString(1);
                String assessmentType = cursor.getString(2);
                String assessmentName = cursor.getString(3);
                String startDate = cursor.getString(4);
                String endDate = cursor.getString(5);

                Assessment assess = new Assessment(aId, assessmentType, assessmentName, courseName, startDate, endDate);
                assessmentsList.add(assess);
                db.close();//??
            }
        } catch (SQLException E) {
            E.getStackTrace();
        }
        return assessmentsList;
    }


    public String getStatus(int courseId) {
        String st = "";
        SQLiteDatabase db = this.getReadableDatabase();
        try {
            Cursor cursor = db.rawQuery("SELECT courseId, status FROM CoursesTable WHERE courseId =" + courseId, null);
            cursor.moveToNext();
            st = cursor.getString(1);
            db.close();
        } catch (SQLException e) {
            e.toString();
        }
        return st;
    }

    public String getSelectedAssessmentItem(int assessId, int position) {
        String st = "";
        SQLiteDatabase db = this.getReadableDatabase();
        try {
            Cursor cursor = db.rawQuery("SELECT assessmentId,assessmentType, course,startDate,endDate,assessmentName FROM AssessmentsTable WHERE assessmentId =" + assessId, null);
            cursor.moveToNext();

            if (position == 1) {
                st = cursor.getString(0);
                db.close();
            } else if (position == 2) {
                st = cursor.getString(1);
                db.close();
            } else if (position == 3) {
                st = cursor.getString(2);
                db.close();
            } else if (position == 4) {
                st = cursor.getString(3);
                db.close();

            } else if (position == 5) {
                st = cursor.getString(4);
                db.close();
            } else if (position == 6) {
                st = cursor.getString(5);
                db.close();
            }
        } catch (SQLException e) {
            e.toString();
        }
        return st;
    }


    public int courseId(String name) {
        int id = -1;
        try {
            SQLiteDatabase db = this.getWritableDatabase();
            Cursor cur = db.rawQuery("select courseId From CoursesTable where courseName = " + "'" + name + "'", null);
            cur.moveToFirst();
            id = cur.getInt(0);
        } catch (SQLException e) {
            e.toString();
        }
        return id;
    }


    public int getSummary(int p) {
        int count = 0;
        SQLiteDatabase db = this.getReadableDatabase();
        try {
            Cursor cursor = db.rawQuery("select DISTINCT (select count(*) from TermTable) Terms " +
                    ",(select count(*)from CoursesTable) Courses " +
                    ",(select count(*)from AssessmentsTable) Assessments " +
                    "from TermTable t left join CoursesTable c " +
                    "on t.termId = c.termId " +
                    "left join AssessmentsTable a " +
                    "on c.courseId = a.courseId", null);
            cursor.moveToNext();
            if (p == 0) {
                if (cursor == null || cursor.getCount() <= 0) {
                    count = 0;
                } else {
                    count = cursor.getInt(0);
                    db.close();
                }
            } else if (p == 1) {
                if (cursor == null || cursor.getCount() <= 0) {
                    count = 0;
                } else {
                    count = cursor.getInt(1);
                    db.close();
                }
            } else if (p == 2) {
                if (cursor == null || cursor.getCount() <= 0) {
                    count = 0;
                } else {
                    count = cursor.getInt(2);
                    db.close();
                }
            }
        } catch (SQLException E) {
            E.getStackTrace();
        }
        // return 0 == ( count == null ? 0 : count);

        return count;
    }

    public boolean getAssessmentCountPerCourse(String cName) {
        int cId = courseId(cName);
        SQLiteDatabase db = this.getReadableDatabase();
        try {
            Cursor cursor = db.rawQuery("select  count( a.assessmentid) " +
                    "from AssessmentsTable a " +
                    "join CoursesTable c " +
                    "on a.courseId = c.courseId " +
                    "where c.courseId = " + cId, null);
            cursor.moveToNext();
            if (cursor.getInt(0) == 5) {
                return true;
            }
        } catch (SQLException e) {
            e.toString();
        }
        return false;
    }


}






