package com.example.c196_zelalem_t.ui.courses;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.c196_zelalem_t.AssessmentsActivity;
import com.example.c196_zelalem_t.R;
import com.example.c196_zelalem_t.TermsActivity;

public class CoursesFragment extends Fragment   {

    private CoursesViewModel coursesViewModel;


//    @Override
//    public void onCreate(@Nullable Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        // This callback will only be called when MyFragment is at least Started.
//        OnBackPressedCallback callback = new OnBackPressedCallback(true /* enabled by default */) {
//            @Override
//            public void handleOnBackPressed() {
//                // Handle the back button event
//            }
//        };
//        requireActivity().getOnBackPressedDispatcher().addCallback(this, callback);
//
//        // The callback can be enabled or disabled here or in handleOnBackPressed()
//    }


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        coursesViewModel =
         ViewModelProviders.of(this).get(CoursesViewModel.class);

        final View root = inflater.inflate(R.layout.fragment_courses, container, false);
      //  final TextView textView = root.findViewById(R.id.text_slideshow);

//
//        Context termMainCont= getActivity().getApplicationContext();
//        Intent termMain = new Intent(termMainCont, CoursesActivity.class);
//        startActivity(termMain);



        coursesViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
         //       textView.setText(s);
            }
        });

        //use
        Context termMainCont= getActivity().getApplicationContext();
        Intent termMain = new Intent(termMainCont, AssessmentsActivity.class);
        startActivity(termMain);
      return root;

    }

    }
