package com.example.c196_zelalem_t.ui.assessments;

import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.c196_zelalem_t.AssessmentsActivity;
import com.example.c196_zelalem_t.R;

public class AssessmentsFragment extends Fragment {

    private AssessmentsViewModel mViewModel;



    public View onCreateView(@NonNull LayoutInflater inflater,  ViewGroup container,
                              Bundle savedInstanceState) {
        mViewModel = ViewModelProviders.of(this).get(AssessmentsViewModel.class);
        View root =  inflater.inflate(R.layout.fragment_assessments, container, false);


        mViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                // textView.setText(s);
            }
        });

        //use
        Context termMainCont= getActivity().getApplicationContext();
        Intent termMain = new Intent(termMainCont, AssessmentsActivity.class);
        startActivity(termMain);
        return root;

    }



}